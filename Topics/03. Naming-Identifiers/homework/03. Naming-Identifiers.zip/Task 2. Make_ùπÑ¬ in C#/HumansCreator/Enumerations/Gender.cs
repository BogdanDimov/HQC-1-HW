﻿namespace HumansCreator.Enumerations
{
    public enum Gender
    {
        UltraBro,
        NiceChick
    }
}
