﻿namespace Task_1._Class_Chef_in_CS.Enums
{
    public enum VegetableType
    {
        Carrot,
        Potato
    }
}
