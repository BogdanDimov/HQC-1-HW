﻿using Task_1._Class_Chef_in_CS.Enums;

namespace Task_1._Class_Chef_in_CS.Models
{
    public class Carrot : Vegetable
    {
        public Carrot() : base(VegetableType.Carrot)
        {
        }
    }
}
