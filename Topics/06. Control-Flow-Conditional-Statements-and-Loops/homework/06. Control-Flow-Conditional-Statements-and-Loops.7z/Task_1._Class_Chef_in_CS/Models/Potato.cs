﻿using Task_1._Class_Chef_in_CS.Enums;

namespace Task_1._Class_Chef_in_CS.Models
{
    public class Potato : Vegetable
    {
        public Potato() : base(VegetableType.Potato)
        {
        }
    }
}
