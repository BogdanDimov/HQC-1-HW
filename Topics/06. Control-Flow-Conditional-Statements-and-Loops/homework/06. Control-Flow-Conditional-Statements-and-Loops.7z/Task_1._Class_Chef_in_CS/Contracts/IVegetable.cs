﻿using Task_1._Class_Chef_in_CS.Enums;

namespace Task_1._Class_Chef_in_CS.Contracts
{
    public interface IVegetable
    {
        VegetableType Type { get; set; }
    }
}