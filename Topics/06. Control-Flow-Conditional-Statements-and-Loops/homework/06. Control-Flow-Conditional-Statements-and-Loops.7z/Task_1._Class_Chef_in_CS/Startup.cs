﻿namespace Task_1._Class_Chef_in_CS
{
    public class Startup
    {
        public static void Main()
        {
            var chef = new Chef();
            chef.Cook();
        }
    }
}
