﻿namespace Task_1._Quality_Methods.Enums
{
    public enum PrintOption
    {
        AsFloatWithTwoDecimalPlaces,
        AsPercent,
        IndentedByEightSpaces
    } 
}