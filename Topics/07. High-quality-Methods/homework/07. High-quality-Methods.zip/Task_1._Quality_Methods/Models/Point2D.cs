﻿namespace Task_1._Quality_Methods.Models
{
    public struct Point2D
    {
        public Point2D(double x, double y)
        {
            this.X = x;
            this.Y = y;
        }

        public double X { get; }

        public double Y { get; }
    }
}
